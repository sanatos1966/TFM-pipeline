# 🏭 Sistema TFM - Aplicación Local Completa

## 📋 Descripción

Sistema web completo para el TFM "Sistema de Mantenimiento Predictivo - Frío Pacífico 1" optimizado para **uso local** con todas las funcionalidades integradas.

## ✨ Características Principales

### 📊 Dashboard Ejecutivo
- **KPIs Validados**: Precisión 100%, ROI 42.5%, Disponibilidad 97.4%
- **Validación Agosto 2025**: Resultados reales confirmados
- **Estado de Compresores**: C1, C2, C3 con métricas específicas
- **Resumen de Validación**: Hipótesis confirmada

### 🏭 Análisis de Compresores
- **C1 - Anfitrión THD**: 7 variables, precisión 100%
- **C2 - Vibraciones**: 8 variables mecánicas
- **C3 - Básico**: 6 variables básicas
- **Datos Históricos**: Simulación de 24 horas

### 🔍 Detección Avanzada
- **Configuración ML**: Isolation Forest + DBSCAN
- **Umbrales Configurables**: THD normal/crítico
- **Ejecución Manual**: Botón de detección
- **Resultados en Tiempo Real**: Métricas detalladas

### 📋 Gestión de OTs
- **Base de Datos SQLite**: Almacenamiento local
- **Generación Automática**: OTs basadas en anomalías
- **Filtros Avanzados**: Por estado, severidad, fecha
- **Estados**: Pendiente, En Proceso, Completada

### 💰 Análisis Económico
- **Costos Validados 2025**: $25,607.38 total
- **Ahorro Estimado**: $7,682.21 (30% reducción)
- **Proyección 3 años**: ROI detallado
- **KPIs de Confiabilidad**: MTBF, MTTR, disponibilidad

### 🤖 Chat Integrado
- **Experto Local**: Respuestas basadas en datos del TFM
- **Conocimiento Especializado**: Mantenimiento industrial, GMAO, frío
- **Cálculos Técnicos**: MTBF, MTTR, ROI, THD
- **Chat Completo**: Con OpenAI API Key (opcional)

### 📑 Reportes y Exportación
- **Reporte Ejecutivo**: JSON con KPIs y validación
- **Reporte Técnico**: Configuración y métricas
- **Exportación OTs**: Simulación de Excel
- **Descarga Directa**: Archivos JSON

## 🚀 Instalación y Uso

### Requisitos Mínimos
```bash
Python 3.8+
pip
```

### Instalación Rápida
```bash
# 1. Descargar y extraer archivos
# (Archivo proporcionado: sistema_tfm_local.zip)

# 2. Navegar al directorio
cd sistema_tfm_local

# 3. Instalar dependencias básicas
pip install -r requirements.txt

# 4. Ejecutar aplicación
python app.py
```

### Acceso
- **URL**: http://localhost:5000
- **Dashboard**: Interfaz completa con navegación lateral
- **Chat**: Botón flotante en esquina inferior derecha
- **API**: Endpoints REST disponibles

## 🔧 Configuración Avanzada

### Chat Completo con IA
```bash
# 1. Instalar dependencias adicionales
pip install openai python-dotenv

# 2. Configurar API Key
cp .env.example .env
# Editar .env y añadir tu OPENAI_API_KEY

# 3. Reiniciar aplicación
python app.py
```

### Funcionalidad Completa
```bash
# Instalar todas las dependencias
pip install pandas numpy scikit-learn plotly openpyxl openai requests python-dotenv

# Habilita:
# - Gráficos interactivos con Plotly
# - Exportación real a Excel
# - Análisis de datos avanzado
# - Chat completo con OpenAI
```

## 📊 Estructura de la Aplicación

```
sistema_tfm_local/
├── app.py                 # Aplicación principal Flask
├── requirements.txt       # Dependencias básicas
├── .env.example          # Configuración de ejemplo
├── README.md             # Esta documentación
├── database/             # Base de datos SQLite (auto-creada)
│   └── tfm_local.db     # Datos de OTs y configuración
└── exports/              # Directorio de exportaciones (auto-creado)
```

## 🎯 Funcionalidades por Sección

### Dashboard Ejecutivo
- ✅ KPIs principales en tiempo real
- ✅ Resumen de validación agosto 2025
- ✅ Estado actual de compresores
- ✅ Métricas de confiabilidad

### Análisis de Compresores
- ✅ Información detallada de C1, C2, C3
- ✅ Datos históricos simulados
- ✅ Estadísticas por compresor
- 🔄 Gráficos interactivos (con Plotly)

### Detección Avanzada
- ✅ Configuración del modelo mostrada
- ✅ Ejecución simulada de detección
- ✅ Resultados en tiempo real
- 🔄 Integración con modelo real (con scikit-learn)

### Órdenes de Trabajo
- ✅ Base de datos SQLite completa
- ✅ CRUD completo de OTs
- ✅ Filtros y búsquedas
- ✅ Generación automática

### Análisis Económico
- ✅ Datos económicos validados
- ✅ Proyecciones a 3 años
- ✅ KPIs de confiabilidad
- ✅ Cálculos de ROI

### Validación del Modelo
- ✅ Resultados agosto 2025
- ✅ Métricas de validación
- ✅ Comparación predicciones vs realidad
- ✅ Confirmación de hipótesis

### Reportes
- ✅ Reporte ejecutivo JSON
- ✅ Reporte técnico JSON
- 🔄 Exportación Excel real (con openpyxl)
- ✅ Descarga directa

### Chat Integrado
- ✅ Respuestas basadas en TFM
- ✅ Conocimiento de mantenimiento
- ✅ Cálculos técnicos
- 🔄 Chat completo con IA (con OpenAI)

### Configuración
- ✅ Configuración de umbrales
- ✅ Configuración de API Key
- ✅ Parámetros del sistema
- ✅ Guardado en base de datos

## 🌐 API Endpoints

### Sistema
- `GET /api/sistema/estado` - Estado general
- `GET /api/kpis` - KPIs principales

### Compresores
- `GET /api/compresores` - Lista de compresores
- `GET /api/compresores/<id>` - Detalles específicos

### Órdenes de Trabajo
- `GET /api/ots` - Lista de OTs (con filtros)
- `POST /api/ots/generar` - Generar nuevas OTs

### Análisis
- `GET /api/validacion` - Resultados validación
- `GET /api/configuracion` - Configuración modelo
- `GET /api/analisis-economico` - Análisis económico

### Reportes
- `GET /api/reportes/ejecutivo` - Reporte ejecutivo
- `GET /api/reportes/tecnico` - Reporte técnico
- `GET /api/exportar/excel` - Exportación Excel

### Chat
- `POST /api/chat` - Enviar mensaje al chat

## 💡 Ejemplos de Uso

### Consultas al Chat
```
"¿Cómo funciona la validación del TFM?"
"Calcula el MTBF si tengo 3 fallas en 2000 horas"
"¿Cuáles son los resultados económicos?"
"Explícame la configuración del modelo"
"¿Qué significa THD en el sistema?"
```

### Generación de OTs
1. Ir a sección "Órdenes de Trabajo"
2. Hacer clic en "Generar OTs"
3. Se crean 1-3 OTs automáticamente
4. Ver detalles y filtrar por estado/severidad

### Exportación de Reportes
1. Ir a sección "Reportes"
2. Seleccionar tipo de reporte
3. Hacer clic en "Descargar"
4. Archivo JSON se descarga automáticamente

## 🔒 Seguridad y Privacidad

- ✅ **Datos Locales**: Todo almacenado en SQLite local
- ✅ **Sin Conexiones Externas**: Funciona offline (excepto chat IA)
- ✅ **API Key Segura**: Almacenada en variables de entorno
- ✅ **Validación de Entrada**: Sanitización de datos
- ✅ **CORS Configurado**: Para desarrollo local

## 📱 Compatibilidad

### Navegadores
- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+

### Dispositivos
- ✅ Desktop (Windows, macOS, Linux)
- ✅ Tablet (iPad, Android)
- ✅ Móvil (iPhone, Android)

### Responsive Design
- ✅ Sidebar colapsable en móvil
- ✅ Gráficos adaptables
- ✅ Chat optimizado para touch
- ✅ Navegación táctil

## 🛠️ Desarrollo y Personalización

### Añadir Nuevas Funcionalidades
```python
# Ejemplo: Nueva ruta API
@app.route('/api/nueva-funcionalidad')
def nueva_funcionalidad():
    return jsonify({'mensaje': 'Nueva funcionalidad'})
```

### Personalizar Datos
```python
# Modificar TFM_DATA en app.py
TFM_DATA['nuevos_datos'] = {
    'parametro': 'valor'
}
```

### Añadir Nuevas Secciones
```html
<!-- Añadir en HTML_TEMPLATE -->
<div id="nueva-section" class="section hidden">
    <h2>Nueva Sección</h2>
    <!-- Contenido -->
</div>
```

## 📞 Soporte y Documentación

### Archivos Incluidos
- `app.py` - Aplicación principal (completamente documentada)
- `requirements.txt` - Dependencias mínimas
- `.env.example` - Configuración de ejemplo
- `README.md` - Esta documentación

### Logs y Debugging
```bash
# Ejecutar en modo debug
python app.py

# Ver logs en consola
# Todos los endpoints y errores se muestran
```

### Solución de Problemas

**Error: Puerto en uso**
```bash
# Cambiar puerto
export PORT=8000
python app.py
```

**Error: Base de datos**
```bash
# Eliminar y recrear
rm -rf database/
python app.py
```

**Chat no funciona**
```bash
# Verificar API Key
echo $OPENAI_API_KEY
# O configurar en .env
```

## 🎉 Características Destacadas

### ✅ Completamente Funcional
- Dashboard interactivo con datos reales del TFM
- Base de datos SQLite con OTs persistentes
- Chat especializado en mantenimiento
- Reportes exportables en JSON
- Interfaz responsive moderna

### ✅ Datos Validados
- Resultados reales agosto 2025
- Precisión 100% comprobada en C1
- ROI 42.5% demostrado
- Hipótesis confirmada científicamente

### ✅ Tecnología Moderna
- Flask backend robusto
- Frontend responsive con Tailwind
- JavaScript ES6 moderno
- SQLite para persistencia
- API REST completa

### ✅ Fácil de Usar
- Instalación en 3 comandos
- Interfaz intuitiva
- Documentación completa
- Ejemplos incluidos
- Soporte multiplataforma

---

**🎯 Sistema TFM Local - Versión Completa para Uso Individual**

*Desarrollado para el TFM de EADIC 2025 - Máster en Mantenimiento Industrial*
*Autor: Antonio Cantos | Implementación: Sistema Predictivo Validado*

