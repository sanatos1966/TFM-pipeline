# Sistema de Mantenimiento Predictivo TFM
## Análisis de Compresores con Datos Reales

### 📋 Descripción del Sistema

Este sistema de mantenimiento predictivo está diseñado para trabajar con **datos reales** de compresores industriales, utilizando técnicas de Machine Learning para detectar anomalías y generar órdenes de trabajo automáticamente.

### 🎯 Objetivos

- Detectar anomalías en compresores usando datos reales de sensores
- Generar órdenes de trabajo preventivas automáticamente
- Validar predicciones contra órdenes de trabajo reales
- Calcular ROI y beneficios económicos reales

### 📁 Estructura de Archivos Requeridos

Para que el sistema funcione correctamente, necesitas colocar los siguientes archivos de datos reales en la carpeta `C:\TFM-pipeline\INPUT\`:

#### Datos Históricos (Entrenamiento)
- `Compresor1_FP1.xlsx` - Datos históricos del Compresor 1
- `Compresor2_FP1.xlsx` - Datos históricos del Compresor 2 (opcional)
- `Compresor3_FP1.xlsx` - Datos históricos del Compresor 3 (opcional)

#### Datos de Inferencia (Agosto 2025)
- `InformacionAgosto_fp1.xlsx` - Datos de agosto 2025 para análisis

#### Órdenes de Trabajo Reales
- `OT-agosto.xlsx` - Órdenes de trabajo reales de agosto 2025
- `Ordenes2025-fp1.xlsx` - Órdenes de trabajo del año 2025

#### Datos de Costos (Opcional)
- Archivos con información de costos de mantenimiento

### 📊 Notebooks del Sistema

#### 1. `TFM_Sistema_Inferencia_Real_Completo.ipynb`
**Notebook principal del sistema**
- Carga y procesa datos reales
- Entrena modelo de detección de anomalías
- Procesa datos de agosto 2025
- Genera diagnósticos automáticos

#### 2. `TFM_Deteccion_Anomalias_Agosto.ipynb`
**Detección especializada de anomalías**
- Análisis específico de datos de agosto
- Detección de patrones anómalos
- Clasificación por severidad

#### 3. `TFM_Generador_OTs_Automatico.ipynb`
**Generación automática de órdenes de trabajo**
- Convierte anomalías en OTs
- Prioriza según severidad
- Calcula costos estimados

#### 4. `TFM_Validacion_Final_OTs_Reales_vs_IA_Corregido.ipynb`
**Validación contra datos reales**
- Compara predicciones IA vs OTs reales
- Calcula métricas de rendimiento
- Análisis económico real

#### 5. `TFM_Sistema_Autoentrenamiento_Continuo.ipynb`
**Sistema de aprendizaje continuo**
- Mejora automática del modelo
- Procesamiento periódico
- Evolución de métricas

#### 6. `TFM_Validacion_Sistema_Real.ipynb`
**Validación integral del sistema**
- Pruebas de todos los componentes
- Verificación de funcionamiento
- Reportes de estado

### 🔧 Configuración del Sistema

#### Estructura de Directorios
```
C:\TFM-pipeline\
├── INPUT\                    # Archivos de datos reales
│   ├── Compresor1_FP1.xlsx
│   ├── InformacionAgosto_fp1.xlsx
│   ├── OT-agosto.xlsx
│   └── Ordenes2025-fp1.xlsx
├── output\                   # Resultados generados
│   ├── VALIDACION_FINAL\
│   ├── ANEXOS_TFM\
│   └── modelos\
└── data\                     # Datos procesados
```

#### Variables Esperadas en los Datos
- **THD (Total Harmonic Distortion)**: THD_V_L1, THD_V_L2, THD_V_L3, THD_I_L1, THD_I_L2, THD_I_L3
- **Variables eléctricas**: Potencia_Activa, Factor_Potencia, Demanda_por_fase
- **Variables de vibración** (C2): Datos de vibración específicos
- **Timestamp**: Marca temporal de cada medición

### 🚀 Instrucciones de Uso

#### Paso 1: Preparar Datos
1. Coloca todos los archivos de datos reales en `C:\TFM-pipeline\INPUT\`
2. Verifica que los archivos tengan las columnas esperadas
3. Asegúrate de que las fechas estén en formato correcto

#### Paso 2: Ejecutar Sistema Principal
1. Abre `TFM_Sistema_Inferencia_Real_Completo.ipynb`
2. Ejecuta todas las celdas secuencialmente
3. El sistema cargará y procesará los datos reales automáticamente

#### Paso 3: Análisis Especializado
1. Ejecuta `TFM_Deteccion_Anomalias_Agosto.ipynb` para análisis detallado
2. Usa `TFM_Generador_OTs_Automatico.ipynb` para generar OTs

#### Paso 4: Validación
1. Ejecuta `TFM_Validacion_Final_OTs_Reales_vs_IA_Corregido.ipynb`
2. Revisa las métricas de rendimiento y ROI real

### 📈 Resultados Esperados

#### Métricas de Rendimiento
- **Precisión**: % de detecciones correctas
- **Recall**: % de problemas reales detectados
- **F1-Score**: Balance entre precisión y recall
- **Anticipación**: Tiempo promedio de detección temprana

#### Análisis Económico
- **Ahorros reales**: Basados en OTs evitadas
- **ROI**: Retorno de inversión calculado con datos reales
- **Costos evitados**: Mantenimientos correctivos y paradas

#### Archivos Generados
- Modelos entrenados (.joblib)
- Reportes de anomalías (.csv)
- OTs generadas automáticamente (.csv)
- Métricas de validación (.json)
- Reportes finales (.md)

### ⚠️ Consideraciones Importantes

#### Calidad de Datos
- Los datos deben estar limpios y completos
- Las fechas deben ser consistentes
- Las variables deben tener nombres estándar

#### Rendimiento
- El sistema está optimizado para datos reales
- No utiliza simulaciones ni datos sintéticos
- Todos los análisis se basan en información real

#### Validación
- Las métricas se calculan contra OTs reales
- El ROI se basa en costos reales de mantenimiento
- Los resultados reflejan el rendimiento real del sistema

### 🔍 Troubleshooting

#### Problemas Comunes
1. **Archivos no encontrados**: Verificar rutas y nombres de archivos
2. **Columnas faltantes**: Revisar estructura de datos esperada
3. **Fechas incorrectas**: Verificar formato de timestamps
4. **Memoria insuficiente**: Procesar datos en lotes más pequeños

#### Soporte
- Revisar logs de error en cada notebook
- Verificar que todos los archivos de datos estén presentes
- Contactar al equipo de desarrollo para problemas específicos

---

**Este sistema está diseñado exclusivamente para trabajar con datos reales de compresores industriales, proporcionando análisis precisos y resultados confiables para la toma de decisiones en mantenimiento predictivo.**

